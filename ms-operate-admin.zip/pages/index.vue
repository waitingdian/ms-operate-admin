<template>
  <div class="container">
  </div>
</template>
<script>
  export default {
    name: 'page-record-index',
    data () {
      return {}
    },
    compontents: {
    }
  }
</script>
<style lang="less">

</style>
