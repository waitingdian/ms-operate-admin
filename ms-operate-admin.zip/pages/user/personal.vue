<template>
  <div>个人邀请的列表(扫某个人二维码进来的列表)
    <div>查询</div>
  </div>
</template>

<script>
  export default {
    name: "index"
  }
</script>

<style scoped>

</style>
